<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo asset('css/navbar.css')?>" type="text/css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('navbar'); ?>

<nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <!-- Collapsed Hamburger -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- Branding Image -->
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    MindGigs &trade;
                </a>
            </div>
            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                <!-- Left Side Of Navbar -->
                <div class="nav navbar-nav navbar-left">
                    <form class="navbar-form"  method="post" action="/skillsearch">
                        <div class="input-group">
                            <?php echo csrf_field(); ?>


                            <input type="text" name="tosearch" class="form-control" style="width: 280px" placeholder="Search for services">
                            <div class="input-group-btn"> <input type="submit"  class="btn btn-default" value="Search"> </div>
                        </div>
                    </form>
                </div>

                <div class="nav navbar-nav">
                    <nav id="navigation" class="menu">
                        <ul id="responsive">



                            <li><a href="/">Home</a>
                                <ul>
                                  <li> <a class="btn btn-default" href="<?php echo e(url('/faq')); ?>">FAQ</a></li>
                                  <li>  <a class="btn btn-default" href="<?php echo e(url('/home')); ?>">Home</a></li>
                                   <li> <a class="btn btn-default" href="<?php echo e(url('/scoreboard')); ?>">Scoreboard</a></li>
                                    <li><a class="btn btn-default" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
                                    <li><a class="btn btn-default" href="<?php echo e(url('/blogs')); ?>">Blogs</a></li>
                                    <li><a class="btn btn-default" href="<?php echo e(url('/searchjobs')); ?>">Jobs Search</a></li>
                                    <li><a class="btn btn-default" href="<?php echo e(url('/dashboard/create')); ?>">Jobs Post</a></li>
                                    <li><a class="btn btn-default" href="<?php echo e(url('/dashboard')); ?>">Jobs View</a></li>
                                    <li><a class="btn btn-default" href="<?php echo e(url('/contactus')); ?>">Contact Us</a></li>
                                </ul>
                            </li>

                            <li><a href="#">For Candidates</a>
                                <ul>
                                    <li><a class="btn btn-default" href="<?php echo e(url('/profile')); ?>">Profile</a></li>
                                    <li><a href="browse-categories.html">Browse Categories</a></li>
                                    <li><a href="add-resume.html">Add Resume</a></li>
                                    <li><a href="manage-resumes.html">Manage Resumes</a></li>
                                    <li><a href="job-alerts.html">Job Alerts</a></li>
                                </ul>
                            </li>

                            <li><a href="#">For Employers</a>
                                <ul>
                                    <li><a href="add-job.html">Add Job</a></li>
                                    <li><a href="manage-jobs.html">Manage Jobs</a></li>
                                    <li><a href="manage-applications.html">Manage Applications</a></li>
                                    <li><a href="browse-resumes.html">Browse Resumes</a></li>
                                </ul>
                            </li>


                        </ul>


                    </nav>

                </div>

                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    <?php if(Auth::guest()): ?>
                        <li><a href="<?php echo e(url('/login')); ?>"> <span class="glyphicon glyphicon-log-in"> Login</span></a></li>
                        <li><a href="<?php echo e(url('/register')); ?>"><span class="glyphicon glyphicon-user"> Register</span></a></li>
                    <?php else: ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url('/'.Auth::user()->name.'/')); ?>"><i class="fa fa-btn fa-user"></i>View My Profile</a></li>
                                <li><a href="<?php echo e(url('/'.Auth::user()->name.'/blogs')); ?>"><i class="fa fa-btn fa-user"></i>View My Blogs</a></li>
                                <li><a href="<?php echo e(url('/'.Auth::user()->name.'/dashboard')); ?>"><i class="fa fa-btn fa-user"></i>View My Dashboard</a></li>
                                <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Logout</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

<?php $__env->stopSection(); ?>

<!-- JavaScripts -->

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(function () {
            "use strict";

            $(window).scroll(function () {
                var $scrollTop = $(this).scrollTop();

                if ($scrollTop > 100) {
                    $(".navbar").addClass("navbar-active");
                } else {
                    $(".navbar").removeClass("navbar-active");
                }
            });


        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>